/*
 * This file is meant to contain the functions - Not implemented for Sprint 1
 */
package paintv0;

/**
 *
 * @author Joe Leveille
 */
public class MainScreenButtonHandlers {
    //TODO: Bring in eventHandlers
    //TODO: Make instance of this class in main class
    MainScreenButtonHandlers(TopMenus menu){
        //
    }
}
