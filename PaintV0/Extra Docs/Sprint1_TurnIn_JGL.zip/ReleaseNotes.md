
Leveille Paint Version 0.0 - 8/28/19

Features added this release:
- Open Image button
    - User can select an image file to display
- Menu bar
    - File, Option & Help buttons
    - File menu is the only one implemented currently
- Within File menu:
    - Save Image button
        - User selects the name, type and location to save the image file
    - Exit Program button
        - Closes PaintV0
- Program now exists and runs
- Scroll bar 

Known Bugs:
- Scroll bars do absolutely nothing
- Image is a tiny, fixed size 
- Adding a picture on top of an already-added picture causes internal errors
- Saving a file before opening an image causes internal errors

Upcoming Solutions/Additions:
- Splitting the program into separate .java files
- Utilize formatting classes to rearrange 
- Image will be a more reasonable size, and possibly resizable on the fly
- Scroll bar will allow user to scroll to the bottom of long pictures

